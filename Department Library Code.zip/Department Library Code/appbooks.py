from flask import Flask, jsonify, request
from flask_sqlalchemy import SQLAlchemy
from flask_cors import CORS

app = Flask(__name__)
CORS(app)  # Enable CORS for frontend requests

# ✅ Configure PostgreSQL Database
app.config["SQLALCHEMY_DATABASE_URI"] = "postgresql://postgres:Rajini@localhost:5432/dept_lib"
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False

db = SQLAlchemy(app)

# ✅ Define Book Model (Matches Your Table Structure)
class Book(db.Model):
    __tablename__ = "books"

    BookID = db.Column(db.Text, primary_key=True)
    ISBN = db.Column(db.Text, nullable=True)
    Title = db.Column(db.Text, nullable=False)
    Author = db.Column(db.Text, nullable=False)
    Category = db.Column(db.Text, nullable=False)
    Publisher = db.Column(db.Text, nullable=True)
    Date_of_release = db.Column(db.DateTime, nullable=True)
    No_of_Pages = db.Column(db.BigInteger, nullable=True)
    No_of_copies = db.Column(db.BigInteger, nullable=True)
    Availability = db.Column(db.Text, nullable=False)
    Added_at = db.Column(db.DateTime, nullable=True)

# ✅ Fetch All Books (Updated to Match Columns)
@app.route("/books", methods=["GET"])
def get_books():
    title = request.args.get("title", "").strip().lower()
    category = request.args.get("category", "").strip().lower()
    availability = request.args.get("availability", "").strip().lower()

    print(f"🔍 Received Filters - Title: {title}, Category: {category}, Availability: {availability}")  # ✅ Debugging

    query = Book.query

    if title:
        query = query.filter(Book.Title.ilike(f"%{title}%"))

    if category:
        query = query.filter(Book.Category.ilike(f"%{category}%"))

    if availability:
        if availability in ["available", "yes", "true", "1"]:
            query = query.filter(Book.Availability.ilike("%yes%"))  # ✅ Matches "yes"
        elif availability in ["borrowed", "no", "false", "0"]:
            query = query.filter(Book.Availability.ilike("%no%"))   # ✅ Matches "no"

    books = query.all()

    print(f"📚 Books found: {len(books)}")  # ✅ Debugging

    books_list = [{
        "BookID": b.BookID,
        "ISBN": b.ISBN,
        "title": b.Title,
        "author": b.Author,
        "category": b.Category,
        "publisher": b.Publisher,
        "date_of_release": b.Date_of_release.isoformat() if b.Date_of_release else None,
        "no_of_pages": b.No_of_Pages,
        "no_of_copies": b.No_of_copies,
        "availability": "Available" if b.Availability.strip().lower() in ["yes", "available", "true", "1"] else "Borrowed",
        "added_at": b.Added_at.isoformat() if b.Added_at else None
    } for b in books]

    return jsonify(books_list)




# ✅ Search Books by Title
@app.route("/books/<title>", methods=["GET"])
def search_book(title):
    book = Book.query.filter_by(Title=title).first()
    if book:
        return jsonify({
            "BookID": book.BookID,
            "ISBN": book.ISBN,
            "Title": book.Title,
            "Author": book.Author,
            "Category": book.Category,
            "Publisher": book.Publisher,
            "Date_of_release": book.Date_of_release,
            "No_of_Pages": book.No_of_Pages,
            "No_of_copies": book.No_of_copies,
            "Availability": book.Availability,
            "Added_at": book.Added_at
        })
    return jsonify({"message": "Book not found"}), 404

# ✅ Run Flask Server
app.run(debug=True)
