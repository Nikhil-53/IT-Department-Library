import bcrypt
import pandas as pd


file_path = "users.xlsx"
xls = pd.ExcelFile(file_path)

df = pd.read_excel(xls)

def hash_password(password):
    # Generate a salt and hash the password
    password_bytes = password.encode('utf-8')
    salt = bcrypt.gensalt()
    hashed = bcrypt.hashpw(password_bytes, salt)
    return hashed

def verify_password(stored_hash, provided_password):
    password_bytes = provided_password.encode('utf-8')
    return bcrypt.checkpw(password_bytes, stored_hash)

df["Password"] = df["Password"].apply(hash_password)

# Save the updated DataFrame to a new Excel file
new_file_path = "department_library_users.xlsx"
df.to_excel(new_file_path, index=False)

