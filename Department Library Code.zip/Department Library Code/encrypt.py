import bcrypt
import pandas as pd
import base64



def hash_password(password):
    password_bytes = password.encode('utf-8')
    salt = bcrypt.gensalt()
    hashed = bcrypt.hashpw(password_bytes, salt)
    # Convert to base64 string for Excel storage
    return base64.b64encode(hashed).decode('utf-8')

def verify_password(stored_hash, provided_password):
    try:
        # Convert provided password to bytes
        password_bytes = provided_password.encode('utf-8')
        # Decode the stored hash from base64
        stored_hash_bytes = base64.b64decode(stored_hash)
        # Verify the password
        return bcrypt.checkpw(password_bytes, stored_hash_bytes)
    except Exception as e:
        print(f"Error verifying password: {e}")
        return False

if __name__ == "__main__":
    file_path = r"D:\Microsoft VS Code\sdp(ADSA)\sdp(ADSA)\users.xlsx"
    xls = pd.ExcelFile(file_path)

    df = pd.read_excel(xls)

    # Hash all passwords in the DataFrame
    df["Password"] = df["Password"].apply(hash_password)

    new_file_path = r"D:\Microsoft VS Code\sdp(ADSA)\sdp(ADSA)\department_library_users.xlsx"
    df.to_excel(new_file_path, index=False)
