from flask import Flask, request, jsonify, session, send_from_directory
from flask_cors import CORS
import pandas as pd
import os
import logging
from encrypt import verify_password, hash_password
import random
import string
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart

# Set up logging
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

app = Flask(__name__)
CORS(app)  # Enable CORS for all routes

# Store verification codes temporarily (in a real app, use Redis or a database)
verification_codes = {}

def generate_verification_code():
    """Generate a random 6-digit verification code"""
    return ''.join(random.choices(string.digits, k=6))

def send_verification_email(recipient_email, verification_code):
    """Send verification code to the user's email"""
    # Email configuration
    sender_email = "itlibrary377@gmail.com"  # TODO: Replace with your Gmail address
    password = "vgbg hynz qjgk qxoo"  # TODO: Replace with your app password (not your regular password)
    
    # IMPORTANT: To use Gmail SMTP, you need to:
    # 1. Turn on 2-Step Verification in your Google Account security settings
    # 2. Create an "App Password" specifically for this application
    # 3. Use that App Password here instead of your regular Gmail password
    # See: https://support.google.com/accounts/answer/185833
    
    # Create message
    message = MIMEMultipart()
    message["From"] = sender_email
    message["To"] = recipient_email
    message["Subject"] = "Password Reset Verification Code"
    
    # Email body
    body = f"""
    Hello,
    
    You have requested to reset your password. Use the following verification code to complete the process:
    
    {verification_code}
    
    If you did not request this, please ignore this email.
    
    Thank you,
    Department Library System
    """
    
    message.attach(MIMEText(body, "plain"))
    
    try:
        # Create SMTP session
        server = smtplib.SMTP("smtp.gmail.com", 587)
        server.starttls()  # Secure the connection
        
        # Login to email server
        server.login(sender_email, password)
        
        # Send email
        text = message.as_string()
        server.sendmail(sender_email, recipient_email, text)
        
        # Close connection
        server.quit()
        
        return True
    except Exception as e:
        logger.error(f"Error sending email: {str(e)}")
        return False

@app.route('/verify-login', methods=['POST'])
def verify_login():
    try:
        login_data = request.get_json()
        
        # Debug print the received data
        logger.debug(f"Received login data: {login_data}")
        
        # Use raw string for Windows path
        excel_path = r"D:\Microsoft VS Code\sdp(ADSA)\sdp(ADSA)\department_library_users.xlsx"
        
        logger.debug(f"Attempting to read Excel file from: {excel_path}")
        
        # Check if file exists
        if not os.path.exists(excel_path):
            logger.error(f"Excel file not found at: {excel_path}")
            return jsonify({"detail": "Excel file not found"}), 404
        
        # Read the Excel file
        try:
            df = pd.read_excel(excel_path)
            logger.debug(f"Excel file read successfully. Columns: {df.columns.tolist()}")
            logger.debug(f"First few rows: {df.head().to_dict()}")
        except Exception as excel_error:
            logger.error(f"Error reading Excel file: {str(excel_error)}")
            return jsonify({"detail": f"Error reading Excel file: {str(excel_error)}"}), 500

        # Clean the data
        df['Email ID'] = df['Email ID'].astype(str).str.strip()
        email = login_data.get('email', '').strip()
        password = login_data.get('password', '').strip()
        
        logger.debug(f"Searching for email: {email}")
        
        # First find the user by email
        user = df[df['Email ID'] == email]
        
        logger.debug(f"Found user records: {len(user)}")
        
        if not user.empty:
            # Get the stored hash for this user
            stored_hash = user.iloc[0]['Password']
            logger.debug("Found stored hash for user")
            
            # Verify the password
            is_valid = verify_password(stored_hash, password)
            logger.debug(f"Password verification result: {is_valid}")
            
            if is_valid:
                logger.info(f"Successful login attempt for email: {email}")
                return jsonify({"status": "success", "message": "Login successful"})
        
        logger.warning(f"Failed login attempt for email: {email}")
        return jsonify({"detail": "Invalid credentials"}), 401
            
    except Exception as e:
        logger.error(f"Unexpected error: {str(e)}")
        logger.error(f"Error type: {type(e)}")
        import traceback
        logger.error(f"Traceback: {traceback.format_exc()}")
        return jsonify({"detail": f"Server error: {str(e)}"}), 500

@app.route('/send-verification-code', methods=['POST'])
def send_verification_code():
    try:
        data = request.get_json()
        email = data.get('email', '').strip()
        
        if not email:
            return jsonify({"detail": "Email is required"}), 400
        
        # Check if email exists in the database
        excel_path = r"D:\Microsoft VS Code\sdp(ADSA)\sdp(ADSA)\department_library_users.xlsx"
        
        if not os.path.exists(excel_path):
            logger.error(f"Excel file not found at: {excel_path}")
            return jsonify({"detail": "Excel file not found"}), 404
        
        df = pd.read_excel(excel_path)
        df['Email ID'] = df['Email ID'].astype(str).str.strip()
        
        # Find the user by email
        user = df[df['Email ID'] == email]
        
        if user.empty:
            logger.warning(f"Email not found for verification: {email}")
            return jsonify({"detail": "Email not found"}), 404
        
        # Generate verification code
        verification_code = generate_verification_code()
        
        # Store verification code (in a real app, associate with session or store in database)
        verification_codes[email] = verification_code
        
        # Send verification email
        email_sent = send_verification_email(email, verification_code)
        
        if email_sent:
            logger.info(f"Verification code sent to: {email}")
            return jsonify({"status": "success", "message": "Verification code sent"})
        else:
            logger.error(f"Failed to send verification email to: {email}")
            return jsonify({"detail": "Failed to send verification email"}), 500
            
    except Exception as e:
        logger.error(f"Unexpected error in send_verification_code: {str(e)}")
        import traceback
        logger.error(f"Traceback: {traceback.format_exc()}")
        return jsonify({"detail": f"Server error: {str(e)}"}), 500

@app.route('/verify-code', methods=['POST'])
def verify_code():
    try:
        data = request.get_json()
        email = data.get('email', '').strip()
        code = data.get('verification_code', '').strip()
        
        if not email or not code:
            return jsonify({"detail": "Email and verification code are required"}), 400
        
        # Check if the verification code matches
        stored_code = verification_codes.get(email)
        
        if not stored_code or stored_code != code:
            logger.warning(f"Invalid verification code for: {email}")
            return jsonify({"detail": "Invalid verification code"}), 400
        
        # Code is valid
        logger.info(f"Verification code validated for: {email}")
        return jsonify({"status": "success", "message": "Verification successful"})
        
    except Exception as e:
        logger.error(f"Unexpected error in verify_code: {str(e)}")
        import traceback
        logger.error(f"Traceback: {traceback.format_exc()}")
        return jsonify({"detail": f"Server error: {str(e)}"}), 500

@app.route('/reset-password', methods=['POST'])
def reset_password():
    try:
        reset_data = request.get_json()
        
        # Debug print the received data
        logger.debug(f"Received password reset data: {reset_data}")
        
        # Get email, new password, and verification code from request
        email = reset_data.get('email', '').strip()
        new_password = reset_data.get('new_password', '').strip()
        verification_code = reset_data.get('verification_code', '').strip()
        
        if not email or not new_password or not verification_code:
            return jsonify({"detail": "Email, new password, and verification code are required"}), 400
        
        # Verify the code
        stored_code = verification_codes.get(email)
        if not stored_code or stored_code != verification_code:
            logger.warning(f"Invalid verification code for password reset: {email}")
            return jsonify({"detail": "Invalid verification code"}), 400
        
        # Code is valid, proceed with password reset
        # Use raw string for Windows path
        excel_path = r"D:\Microsoft VS Code\sdp(ADSA)\sdp(ADSA)\department_library_users.xlsx"
        
        logger.debug(f"Attempting to read Excel file from: {excel_path}")
        
        # Check if file exists
        if not os.path.exists(excel_path):
            logger.error(f"Excel file not found at: {excel_path}")
            return jsonify({"detail": "Excel file not found"}), 404
        
        try:
            # Read the Excel file
            df = pd.read_excel(excel_path)
            logger.debug(f"Excel file read successfully for password reset")
            
            # Clean the data
            df['Email ID'] = df['Email ID'].astype(str).str.strip()
            
            # Find the user by email
            user_mask = df['Email ID'] == email
            
            if not any(user_mask):
                logger.warning(f"Email not found for password reset: {email}")
                return jsonify({"detail": "Email not found"}), 404
            
            # Hash the new password
            hashed_password = hash_password(new_password)
            
            # Update the password for this user
            df.loc[user_mask, 'Password'] = hashed_password
            
            # Save the updated DataFrame back to Excel
            df.to_excel(excel_path, index=False)
            
            # Remove the used verification code
            if email in verification_codes:
                del verification_codes[email]
            
            logger.info(f"Password successfully reset for email: {email}")
            return jsonify({"status": "success", "message": "Password reset successful"})
            
        except Exception as excel_error:
            logger.error(f"Error updating Excel file: {str(excel_error)}")
            return jsonify({"detail": f"Error updating Excel file: {str(excel_error)}"}), 500
            
    except Exception as e:
        logger.error(f"Unexpected error in password reset: {str(e)}")
        import traceback
        logger.error(f"Traceback: {traceback.format_exc()}")
        return jsonify({"detail": f"Server error: {str(e)}"}), 500

# Set the directory containing the HTML file to the current directory
app.static_folder = os.path.abspath(os.path.dirname(__file__))

@app.route('/')
def home():
    # Serve the HTML file from the static folder
    return send_from_directory(app.static_folder, 'Untitled-1.html')

if __name__ == '__main__':
    app.run(debug=True, port=8000) 