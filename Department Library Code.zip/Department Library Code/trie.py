class TrieNode:
    def __init__(self):
        self.children = {}
        self.is_end = False
        self.suggestions = []

class Trie:
    def __init__(self):
        self.root = TrieNode()
        self.all_books = {}  

    def insert(self, book):
        book_key = book["title"].lower()  

        if book_key in self.all_books:
            return  

        self.all_books[book_key] = book  

        node = self.root
        for char in book_key:
            if char not in node.children:
                node.children[char] = TrieNode()
            node = node.children[char]

            if book not in node.suggestions:
                if len(node.suggestions) < 10:
                    node.suggestions.append(book)

        node.is_end = True

    def search(self, query):
        query = query.lower()
        if not query:
            return list(self.all_books.values()) 

        node = self.root
        for char in query:
            if char not in node.children:
                break
            node = node.children[char]
        else:
            if node.suggestions:
                return node.suggestions 

        keyword_matches = [
            book for book in self.all_books.values()
            if query in book["title"].lower() or query in book["author"].lower()
        ]
        return keyword_matches[:10]  

def create_books_trie(books):
    trie = Trie()
    for book in books:
        trie.insert(book)  
    return trie
