document.addEventListener('DOMContentLoaded', function() {
    const searchInput = document.getElementById('searchInput');
    const suggestionsList = document.getElementById('suggestionsList');
    const searchButton = document.getElementById('searchButton');
    const searchResults = document.getElementById('searchResults');
    const resultsContainer = document.getElementById('resultsContainer');
    const cartCountBadge = document.getElementById('cartCount');
    let currentFocus = -1;

    document.addEventListener("DOMContentLoaded", function () {
        const cartCountBadge = document.getElementById("cartCount");
    
        async function updateCartCount() {
            try {
                const response = await fetch('http://127.0.0.1:5000/cart-count');
                if (!response.ok) {
                    throw new Error(`HTTP error! status: ${response.status}`);
                }
                const data = await response.json();
                cartCountBadge.textContent = data.count || '0';
            } catch (error) {
                console.error('Error updating cart count:', error);
            }
        }
    
        // Call updateCartCount on page load and after cart modifications
        updateCartCount();
        async function removeFromCart(book) {
            try {
                const response = await fetch('/cart/remove', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-Requested-With': 'XMLHttpRequest'
                    },
                    body: JSON.stringify(book)
                });
        
                if (!response.ok) {
                    const errorData = await response.json();
                    throw new Error(errorData.error || 'Failed to remove book from cart');
                }
        
                const result = await response.json();
        
                // ✅ Remove the card or row from DOM
                const bookElement = document.querySelector(`[data-book-title="${book.title}"]`);
                if (bookElement) {
                    bookElement.remove();
                }
        
                // ✅ Update the cart count
                const cartCountBadge = document.getElementById('cartCount');
                if (cartCountBadge && result.cart_count !== undefined) {
                    cartCountBadge.textContent = result.cart_count;
                }
        
                alert('Book removed from cart');
            } catch (error) {
                console.error('Error removing book from cart:', error);
                alert(error.message || 'Failed to remove book from cart. Please try again.');
            }
        }
        
        // Display all books on page load
        displayAllBooks();
        // Make sure the results container is visible
        searchResults.classList.remove('d-none');
    
        // Debounce function to limit API calls
        function debounce(func, wait) {
            let timeout;
            return function executedFunction(...args) {
                const later = () => {
                    clearTimeout(timeout);
                    func(...args);
                };
                clearTimeout(timeout);
                timeout = setTimeout(later, wait);
            };
        }
    
        // Fetch suggestions from the server
        const fetchSuggestions = debounce(async (prefix) => {
            try {
                const response = await fetch(`/suggest?prefix=${encodeURIComponent(prefix)}`);
                if (!response.ok) throw new Error('Network response was not ok');
                const suggestions = await response.json();
                displaySuggestions(suggestions);
            } catch (error) {
                console.error('Error fetching suggestions:', error);
                suggestionsList.classList.add('d-none');
            }
        }, 300);
    
        // Display suggestions in the dropdown
        function displaySuggestions(suggestions) {
            if (!suggestions.length) {
                suggestionsList.classList.add('d-none');
                return;
            }
    
            suggestionsList.innerHTML = '';
            suggestions.forEach((book, index) => {
                const div = document.createElement('div');
                div.className = 'suggestion-item';
                div.innerHTML = `
                    <div class="book-title">${book.title}</div>
                    <div class="book-info">by ${book.author} (${book.year})</div>
                `;
                div.addEventListener('click', () => {
                    searchInput.value = book.title;
                    suggestionsList.classList.add('d-none');
                });
                suggestionsList.appendChild(div);
            });
            suggestionsList.classList.remove('d-none');
        }
    
        // Display search results
        function displaySearchResults(books) {
            searchResults.classList.remove('d-none');
    
            if (!books.length) {
                resultsContainer.innerHTML = '<p class="text-center">No books found matching your search.</p>';
                return;
            }
    
            resultsContainer.innerHTML = books.map(book => `
                <div class="book-item mb-3">
                    <div class="d-flex justify-content-between align-items-start">
                        <div>
                            <h5 class="book-title">${book.title}</h5>
                            <div class="book-info">
                                <span>Author: ${book.author}</span>
                                <span class="ms-3">Year: ${book.year}</span>
                            </div>
                        </div>
                        <button class="btn btn-primary btn-sm add-to-cart" 
                                data-book='${JSON.stringify(book).replace(/'/g, "&apos;")}'>
                            Add to Cart
                        </button>
                    </div>
                </div>
            `).join('<hr>');
    
            // Add event listeners to all Add to Cart buttons
            document.querySelectorAll('.add-to-cart').forEach(button => {
                button.addEventListener('click', async function() {
                    const book = JSON.parse(this.dataset.book.replace(/&apos;/g, "'"));
                    await addToCart(book);
                });
            });
        }
    
        // Add to cart functionality
        async function addToCart(book) {
            try {
                console.log('Attempting to add book:', book); // Debug log
                
                const response = await fetch('/cart/add', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify(book)
                });
    
                console.log('Response status:', response.status); // Debug log
                
                const result = await response.json();
                console.log('Response data:', result); // Debug log
    
                if (!response.ok) {
                    throw new Error(`Failed to add book: ${result.error || 'Unknown error'}`);
                }
    
                updateCartCount(result.cart_count);
    
                // Show success feedback on the clicked button
                const buttons = document.querySelectorAll('.add-to-cart');
                const button = Array.from(buttons).find(btn => {
                    const btnBook = JSON.parse(btn.dataset.book.replace(/&apos;/g, "'"));
                    return btnBook.title === book.title;
                });
    
                if (button) {
                    const originalText = button.textContent;
                    button.textContent = 'Added!';
                    button.disabled = true;
                    setTimeout(() => {
                        button.textContent = originalText;
                        button.disabled = false;
                    }, 2000);
                }
    
            } catch (error) {
                console.error('Detailed error:', error); // More detailed error logging
                console.error('Error stack:', error.stack); // Stack trace
                alert('Failed to add book to cart. Please try again.');
            }
        }
    
        // Update cart count badge
        async function updateCartCount(count) {
            if (count !== undefined) {
                cartCountBadge.textContent = count;
            } else {
                try {
                    const response = await fetch('/cart');
                    const html = await response.text();
                    const parser = new DOMParser();
                    const doc = parser.parseFromString(html, 'text/html');
                    const cartItems = doc.querySelectorAll('.cart-item');
                    cartCountBadge.textContent = cartItems.length;
                } catch (error) {
                    console.error('Error updating cart count:', error);
                }
            }
        }
    
        // Search button click handler
        searchButton.addEventListener('click', async () => {
            const query = searchInput.value.trim();
            if (!query) return;
    
            try {
                const response = await fetch(`/suggest?prefix=${encodeURIComponent(query)}`);
                if (!response.ok) throw new Error('Network response was not ok');
                const results = await response.json();
                displaySearchResults(results);
            } catch (error) {
                console.error('Error performing search:', error);
                resultsContainer.innerHTML = '<p class="text-center text-danger">An error occurred while searching. Please try again.</p>';
            }
        });
    
        // Input event handler
        searchInput.addEventListener('input', (e) => {
            const value = e.target.value.trim();
            if (value.length > 0) {
                fetchSuggestions(value);
            } else {
                suggestionsList.classList.add('d-none');
            }
        });
    
        // Keyboard navigation
        searchInput.addEventListener('keydown', (e) => {
            const items = suggestionsList.getElementsByClassName('suggestion-item');
    
            if (e.key === 'ArrowDown') {
                currentFocus++;
                addActive(items);
                e.preventDefault();
            } else if (e.key === 'ArrowUp') {
                currentFocus--;
                addActive(items);
                e.preventDefault();
            } else if (e.key === 'Enter') {
                e.preventDefault();
                if (currentFocus > -1) {
                    if (items) items[currentFocus].click();
                } else {
                    searchButton.click(); // Trigger search if no suggestion is selected
                }
            }
        });
        function addToCart(bookData) {
            fetch('/add-to-cart', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(bookData)
            })
            .then(response => {
                if (response.status === 401) {
                    // Handle unauthorized access
                    window.location.href = '/login';
                    throw new Error('Please login first');
                }
                return response.json();
            })
            .then(data => {
                if (data.success) {
                    // Update cart count
                    updateCartCount(data.cart_count);
                    alert(data.message);
                } else {
                    alert(data.message);
                }
            })
            .catch(error => {
                console.error('Error:', error);
                if (error.message !== 'Please login first') {
                    alert(error.message);
                }
            });
        }
        // Add active class to selected item
        function addActive(items) {
            if (!items) return;
            removeActive(items);
            if (currentFocus >= items.length) currentFocus = 0;
            if (currentFocus < 0) currentFocus = items.length - 1;
            items[currentFocus].classList.add('active');
        }
    
        // Remove active class from items
        function removeActive(items) {
            for (let item of items) {
                item.classList.remove('active');
            }
        }
    
        // Close suggestions when clicking outside
        document.addEventListener('click', (e) => {
            if (!searchInput.contains(e.target) && !suggestionsList.contains(e.target)) {
                suggestionsList.classList.add('d-none');
            }
        });
    
        // Function to display all books
        async function displayAllBooks() {
            try {
                const response = await fetch('/all-books'); // Using the correct endpoint
                if (!response.ok) throw new Error('Network response was not ok');
                const books = await response.json();
                let displayBooks = books;
                if (availabilityFilter === 'available') {
                    displayBooks = books.filter(book => book.availability.toLowerCase().trim() === 'available');
                } else if (availabilityFilter === 'borrowed') {
                    displayBooks = books.filter(book => book.availability.toLowerCase().trim() !== 'available');
                }
                displaySearchResults(displayBooks);
            } catch (error) {
                console.error('Error fetching all books:', error);
                resultsContainer.innerHTML = '<p class="text-center text-danger">An error occurred while fetching books. Please try again.</p>';
            }
        }
    
        // Update the checkout event listener
        document.addEventListener('DOMContentLoaded', function() {
            // Update checkout button event listener
            const checkoutBtn = document.querySelector('.checkout-btn');
            if (checkoutBtn) {
                checkoutBtn.addEventListener('click', checkout);
            }
        });
    
        // Update the checkout function
        async function checkout() {
            try {
                const response = await fetch('/cart/checkout', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-Requested-With': 'XMLHttpRequest'
                    }
                });
    
                if (!response.ok) {
                    const errorData = await response.json();
                    throw new Error(errorData.error || 'Failed to checkout');
                }
    
                const result = await response.json();
                
                // Get all books from cart before clearing
                const cartItems = document.querySelectorAll('.cart-item');
                const books = Array.from(cartItems).map(item => ({
                    title: item.querySelector('h5').textContent,
                    author: item.querySelector('.text-secondary span:first-child').textContent.replace('Author: ', '')
                }));
    
                // Clear cart content
                const cartContent = document.getElementById('cartContent');
                if (cartContent) {
                    cartContent.innerHTML = `
                        <div class="receipt-container p-4">
                            <div class="text-center mb-4">
                                <h4>Reservation Receipt</h4>
                                <p class="text-muted">Please collect your books within 24 hours</p>
                            </div>
                            <div class="border rounded p-3 mb-3">
                                <h5>Reserved Books:</h5>
                                ${books.map(book => `
                                    <div class="mb-2">
                                        <strong>${book.title}</strong><br>
                                        <small class="text-muted">by ${book.author}</small>
                                    </div>
                                `).join('')}
                                <hr>
                                <div class="text-muted mt-3">
                                    <p>Reservation Date: ${new Date().toLocaleString()}</p>
                                    <p>Expiry: ${new Date(Date.now() + 24 * 60 * 60 * 1000).toLocaleString()}</p>
                                    <p class="mb-0">Please bring your student ID when collecting books.</p>
                                </div>
                            </div>
                            <div class="text-center">
                                <button class="btn btn-primary" onclick="window.print()">Print Receipt</button>
                                <a href="/home" class="btn btn-outline-primary ms-2">Back to Search</a>
                            </div>
                        </div>
                    `;
                }
    
                // Update cart count
                updateCartCount(0);
    
                // Load reserved books
                loadReservedBooks();
    
            } catch (error) {
                console.error('Error during checkout:', error);
                alert(error.message || 'Failed to checkout. Please try again.');
            }
        }
    });